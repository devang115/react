// FetchData.js

import React, { useState, useEffect } from "react";
import axios from "axios";

const FetchData = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const result = await axios.get(
          "https://66226db427fcd16fa6c9cba1.mockapi.io/dev"
        );
        setData(result.data);
        console.log(result.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  const submitData = async (getData) => {
    try {
      await axios.post(
        "https://66226db427fcd16fa6c9cba1.mockapi.io/dev",
        getData
      );
      alert("Data added successfully");
    } catch (error) {
      console.error("Error adding data:", error);
    }
  };

  return <></>;
};

export default FetchData;
