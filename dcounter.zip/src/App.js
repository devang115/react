// App.js

import React from "react";
// import FetchData from "./FetchData";
// import ReactHookForm from "./ReactHookForm";
// import Formvalidation from "./component/pages/formvalidation";
import Counter from "./Counter";

function App() {
  return (
    <div>
      {/* <h1>Fetching Data Example</h1> */}
      {/* <FetchData /> */}
      {/* <ReactHookForm /> */}
      {/* <Formvalidation /> */}
      <Counter />
    </div>
  );
}

export default App;
