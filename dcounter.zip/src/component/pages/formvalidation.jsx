import React, { useState } from "react";
import { useForm } from "react-hook-form";
import axios from "axios";

function Formvalidation() {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const [submittedData, setSubmittedData] = useState(null);

  async function submitData(data) {
    await axios
      .post("https://66211a783bf790e070b1d62c.mockapi.io/User", data)
      .then((res) => {
        setSubmittedData(data);
        alert("Data has been Added");
      });
  }

  return (
    <>
      <div className="col-6 mx-auto p-5 my-5 shadow">
        <h2>Register Form</h2>
        <form onSubmit={handleSubmit(submitData)}>
          <input
            type="text"
            className="form-control mt-5"
            {...register("username", {
              required: {
                value: true,
                message: "Enter Your UserName",
              },
              minLength: {
                value: 3,
                message: "atleast 3 Charcter",
              },
              maxLength: {
                value: 10,
                message: "Maximum  10 Charcter ",
              },
            })}
            placeholder="Enter Your Username"
          />
          <span>{errors.username && errors.username.message}</span>

          <input
            type="text"
            className="form-control mt-5"
            {...register("email", {
              required: {
                value: true,
                message: "Enter Your Email",
              },
              minLength: {
                value: 3,
                message: "atleast 3 Charcter",
              },
              maxLength: {
                value: 10,
                message: "Maximum  10 Charcter ",
              },
            })}
            placeholder="Enter Your Email"
          />
          <span>{errors.email && errors.email.message}</span>

          <input
            type="text"
            className="form-control mt-5"
            {...register("mobile", {
              required: {
                value: true,
                message: "Enter Your Contact number",
              },
              minLength: {
                value: 3,
                message: "atleast 3 Charcter",
              },
              maxLength: {
                value: 10,
                message: "Maximum  10 Charcter ",
              },
            })}
            placeholder="Enter Your Contact number"
          />
          <span>{errors.mobile && errors.mobile.message}</span>

          <button className="btn btn-success mt-4" type="submit">
            Submit
          </button>
        </form>
      </div>

      {submittedData && (
        <div className="col-6 mx-auto p-5 my-5 shadow">
          <h2>Submitted Data</h2>
          <p>
            <strong>Username:</strong> {submittedData.username}
          </p>
          <p>
            <strong>Email:</strong> {submittedData.email}
          </p>
          <p>
            <strong>Contact Number:</strong> {submittedData.mobile}
          </p>
        </div>
      )}
    </>
  );
}

export default Formvalidation;
