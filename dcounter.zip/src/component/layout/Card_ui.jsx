// Import necessary dependencies
import React from "react";

// Define ExplorerCard component using class
class ExplorerCard extends React.Component {
  render() {
    return (
      <div className="card">
        {/* Render image */}
        <img
          src="https://example.com/image.jpg"
          className="card-img-top"
          alt="Card"
        />
        <div className="card-body">
          <h5 className="card-title">{this.props.title}</h5>
          <p className="card-text">{this.props.description}</p>
          {/* Use button instead of anchor tag */}
          <button className="btn btn-primary">Go somewhere</button>
        </div>
      </div>
    );
  }
}

// Export ExplorerCard component
export default ExplorerCard;
