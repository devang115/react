// Card.js

import React from "react";

// Function component for displaying card UI
function Card(props) {
  return (
    <div className="card">
      {/* Image */}
      <img src={props.imageUrl} alt="card" />

      {/* Description */}
      <h2>{props.title}</h2>

      {/* Paragraph */}
      <p>{props.description}</p>
    </div>
  );
}

export default Card;
