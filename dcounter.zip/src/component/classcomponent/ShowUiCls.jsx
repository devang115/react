import React from "react";
import { Component } from "react";

import CardclsUi from "../../class/CardClsUi";

//class ShowUi Extends React.Component{
//}
class ShowUicls extends Component {
  render() {
    return (
      <>
        <h1>Class Component</h1>
        <div className="Container">
          <div className="row">
            <div className="col-lg-4">
              <CardclsUi
                title="WedSite"
                para=" Lorem, ipsum dolor sit amet consectetur adipisicing elit. Accusantium beatae voluptatum, asperiores 
                harum iusto eum tempora sit voluptatem, molestiae quos et eius? Voluptatum, delectus molestiae. Exercitationem 
                aliquam doloribus excepturi at!"
              />
            </div>
            <div className="col-lg-4">
              <CardclsUi
                title="Browser"
                para=" Lorem, ipsum dolor sit amet consectetur adipisicing elit. Accusantium beatae voluptatum, asperiores 
                harum iusto eum tempora sit voluptatem, molestiae quos et eius? Voluptatum, delectus molestiae. Exercitationem 
                aliquam doloribus excepturi at!"
              />
            </div>
            <div className="col-lg-4">
              <CardclsUi
                title="Server"
                para=" Lorem, ipsum dolor sit amet consectetur adipisicing elit. Accusantium beatae voluptatum, asperiores 
                harum iusto eum tempora sit voluptatem, molestiae quos et eius? Voluptatum, delectus molestiae. Exercitationem 
                aliquam doloribus excepturi at!"
              />
            </div>
          </div>
        </div>
      </>
    );
  }
}
export default ShowUicls;
