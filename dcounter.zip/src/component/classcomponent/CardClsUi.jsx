import { Component } from "react";

class CardClsUi extends Component {
  constructor(props) {
    super();
  }
  render() {
    return (
      <div className="card">
        <img src="" alt="" />
        <div className="card-body">
          <h3>{this.props.title}</h3>
          <p>{this.props.para}</p>
        </div>
      </div>
    );
  }
}
export default CardClsUi;
