// React Component with Delete and Edit Functionality
import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";

function ReactHookForm() {
  const { register, handleSubmit, setValue } = useForm();
  const [registeredData, setRegisteredData] = useState([]);
  const [editIndex, setEditIndex] = useState(null);

  // Function to handle form submission
  const onSubmit = async (data) => {
    try {
      if (editIndex !== null) {
        await fetch(
          `https://66226db427fcd16fa6c9cba1.mockapi.io/dev/${registeredData[editIndex].id}`,
          {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
          }
        );
        setEditIndex(null);
      } else {
        const response = await fetch(
          "https://66226db427fcd16fa6c9cba1.mockapi.io/dev",
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(data),
          }
        );
        if (response.ok) {
          alert("Data added successfully");
        } else {
          console.error("Failed to add data:", response.statusText);
        }
      }
      fetchRegisteredData();
    } catch (error) {
      console.error("Error adding data:", error);
    }
  };

  // Function to fetch registered data
  const fetchRegisteredData = async () => {
    try {
      const response = await fetch(
        "https://66226db427fcd16fa6c9cba1.mockapi.io/dev"
      );
      if (response.ok) {
        const data = await response.json();
        setRegisteredData(data);
      } else {
        console.error("Failed to fetch registered data:", response.statusText);
      }
    } catch (error) {
      console.error("Error fetching registered data:", error);
    }
  };

  // Function to delete data
  const deleteData = async (id) => {
    try {
      const response = await fetch(
        `https://66226db427fcd16fa6c9cba1.mockapi.io/dev/${id}`,
        {
          method: "DELETE",
        }
      );
      if (response.ok) {
        fetchRegisteredData();
      } else {
        console.error("Failed to delete data:", response.statusText);
      }
    } catch (error) {
      console.error("Error deleting data:", error);
    }
  };

  // Function to set data for editing
  const editData = (index) => {
    setEditIndex(index);
    const item = registeredData[index];
    setValue("username", item.username);
    setValue("email", item.email);
    setValue("mobile", item.mobile);
  };

  useEffect(() => {
    // Fetch registered data when component mounts
    fetchRegisteredData();
  }, []);

  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-md-6 mx-auto">
            <div className="card mt-5">
              <div className="card-body">
                <h2 className="card-title text-center">Register Form</h2>
                <form onSubmit={handleSubmit(onSubmit)}>
                  <div className="form-group">
                    <input
                      type="text"
                      className="form-control"
                      {...register("username")}
                      placeholder="Enter Your Username"
                    />
                  </div>
                  <div className="form-group">
                    <input
                      type="text"
                      className="form-control"
                      {...register("email")}
                      placeholder="Enter Your Email"
                    />
                  </div>
                  <div className="form-group">
                    <input
                      type="text"
                      className="form-control"
                      {...register("mobile")}
                      placeholder="Enter Your Contact number"
                    />
                  </div>
                  <button className="btn btn-success btn-block" type="submit">
                    {editIndex !== null ? "Update" : "Submit"}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>

        <div className="row mt-5">
          <div className="col-md-6 mx-auto">
            <div className="card">
              <div className="card-body">
                <h2 className="card-title text-center">Registered Data</h2>
                <table className="table">
                  <thead>
                    <tr>
                      <th>Username</th>
                      <th>Email</th>
                      <th>Contact number</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {registeredData.map((item, index) => (
                      <tr key={index}>
                        <td>{item.username}</td>
                        <td>{item.email}</td>
                        <td>{item.mobile}</td>
                        <td>
                          <button
                            className="btn btn-primary btn-sm mr-2"
                            onClick={() => editData(index)}
                          >
                            Edit
                          </button>
                          <button
                            className="btn btn-danger btn-sm"
                            onClick={() => deleteData(item.id)}
                          >
                            Delete
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default ReactHookForm;
