const Home = () => {
  return (
    <>
      <h1>Home Page</h1>
      <div className="container">
        <div ClassName="row">
          <div className="col-md-4">
            <cardUi
              title="Web development"
              para="Web development refers to the tasks associated with creating, building, and maintaining websites."
            />
          </div>
          <div className="col-md-4">
            <cardUi
              title="app development"
              para="App development refers to the tasks associated with creating, building, and maintaining mobile applications."
            />
          </div>
          <div className="col-md-4">
            <cardUi
              title="Ui/ux design"
              para="Ui/ux design refers to the process of creating user-friendly interfaces for digital products."
            />
          </div>
        </div>
      </div>
           
    </>
  );
};
