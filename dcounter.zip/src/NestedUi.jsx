import CardUi from "./CardUi";
import data from "./data";
const NestedUi = () => {
  return (
    <>
      <div className="container my-5">
        <div className="row">
          {data.map((item) => (
            <CardUi
              key={item.id}
              title={item.title}
              para={item.para}
              image={item.images}
            />
          ))}
        </div>
      </div>
    </>
  );
};
export default NestedUi;
