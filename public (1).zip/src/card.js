// Card.js
import React from "react";
import "./App.css";

function Card({ restaurant }) {
  // Check if the restaurant object exists before accessing its properties
  if (!restaurant) {
    return null; // Return null if the restaurant object is undefined or null
  }

  return (
    <div className="card">
      {restaurant.image && (
        <img
          src={restaurant.image}
          alt={restaurant.name}
          className="card-image"
        />
      )}
      <div className="card-content">
        <h2 className="card-title">{restaurant.name}</h2>
        <p className="card-description">{restaurant.description}</p>
        <p className="card-location">{restaurant.location}</p>
        <p className="card-rating">Rating: {restaurant.rating}</p>
      </div>
    </div>
  );
}

export default Card;
