import React, { useState, useEffect } from "react";

const ApiCall = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          "https://jsonplaceholder.typicode.com/photos"
        );
        const jsonData = await response.json();
        setData(jsonData);
        console.log(jsonData);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };

    fetchData();
  }, []);

  return (
    <>
      <h1>App call</h1>
      {data.map((photo) => (
        <div className="card container mt-4 shadow" key={photo.id}>
          <div className="card-body">
            <img src={photo.url} alt={photo.title} />
            <h5 className="card-title">{photo.title}</h5>
          </div>
        </div>
      ))}
    </>
  );
};

export default ApiCall;
