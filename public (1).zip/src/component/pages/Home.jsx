import Cardui from "../layout/Cardui";

const Home = () => {
  return (
    <>
      <h1>Home</h1>
      <div className="container">
        <div className="row">
          <div className="col-lg-4">
            <Cardui title="patel" para="lorem" />
          </div>
          <div className="col-lg-4">
            <Cardui title="shailesh" para="lorem" />
          </div>
          <div className="col-lg-4">
            <Cardui title="vasantbhai" para="lorem" />
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;

// const obj = {
//     id : 123,
//     name : "shailesh",
//     title : "hello",
//     para : "lorem"
// }
// const {id,name,title,para} = obj;
// console.log(title)
// console.log(para)
// export default Cardui

// const Cardui = ({title,para})=>{
//     return(
//         <div className="card">
//             <img src="" alt="" />
//             <div className="catd-title">
//                 <h3>{title}</h3>
//                 <p>{para??"no data"}</p>
//             </div>
//         </div>
//     )
// }
