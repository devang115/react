// Import necessary dependencies
import React from "react";
import ExplorerCard from "./card_ui";

// Define Explorer component using function
function Explorer() {
  return (
    <div>
      <h2>Explorer</h2>
      {/* Render ExplorerCard component */}
      <ExplorerCard
        title="Sample Title"
        description="This is a sample description."
      />
    </div>
  );
}

// Export Explorer component
export default Explorer;
