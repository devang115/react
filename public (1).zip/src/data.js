const data = [
  {
    id: 1,
    name: "shailesh",
    title: "hello",
    para: "lorem",
    images: "https://picsum.photos/200/300",
  },
  {
    id: 2,
    name: "vasantbhai",
    title: "hello",
    para: "lorem",
    images: "https://picsum.photos/200/302",
  },
  {
    id: 3,
    name: "patel",
    title: "hello",
    para: "lorem",
    images: "https://picsum.photos/200/301",
  },
];
export default data;
