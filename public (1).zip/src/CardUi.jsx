const CardUi = ({ title, para, image }) => {
  return (
    <div className="Card">
      <img src={image} alt="" />

      <div className="Card-body">
        <h3>{title}</h3>
        <p>{para ?? "NO Paragraph"}</p>
        <p>{}</p>
      </div>
    </div>
  );
};

export default CardUi;
