import React from "react";
import Card from "./component/layout/Card";
const cardData = [
  {
    id: 1,
    imageUrl: "https://picsum.photos/200/300",
    title: "Card 1",
    description: "Description for Card 1",
  },
  {
    id: 2,
    imageUrl: "https://picsum.photos/200/310",
    title: "Card 2",
    description: "Description for Card 2",
  },
];

function App() {
  return (
    <div className="App">
      <h1>Card UI</h1>
      <div className="card-container">
        {cardData.map((card) => (
          <Card
            key={card.id}
            imageUrl={card.imageUrl}
            title={card.title}
            description={card.description}
          />
        ))}
      </div>
    </div>
  );
}

export default App;
