import React, { useState } from "react";

const ApiCall = () => {
  const [data, setData] = useState([]);

  async function showApi() {
    try {
      const response = await fetch(
        "https://jsonplaceholder.typicode.com/users"
      );
      const jsonData = await response.json();
      setData(jsonData);
      console.log(jsonData);
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  return (
    <>
      <h1>App call</h1>
      <button onClick={showApi}>Call API</button>
      {data.map((user) => (
        <div className="card container mt-4 shadow" key={user.id}>
          <div className="card-body">
            <h5 className="card-title">{user.name}</h5>
            <p className="card-text">{user.email}</p>
          </div>
        </div>
      ))}
    </>
  );
};

export default ApiCall;
